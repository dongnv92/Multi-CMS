<?php
header('Content-Type: application/json');
switch ($path[2]){
    default:

        break;
}
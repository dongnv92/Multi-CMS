<?php
switch ($path[2]) {
    default:
        break;
}
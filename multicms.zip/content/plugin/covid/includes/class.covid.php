<?php
class pCovid{

}
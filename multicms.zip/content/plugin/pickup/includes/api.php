<?php
header('Content-Type: application/json');
switch ($path[2]){
    case 'add':

        break;
    default:

        break;
}